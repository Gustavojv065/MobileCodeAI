#!/usr/bin/env sh
set -eu

if ! command -v java >/dev/null 2>&1; then
  echo "Java 17 não encontrado." >&2
  exit 1
fi

if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle não encontrado. Abra o projeto no Android Studio ou instale Gradle 8.9." >&2
  exit 1
fi

if [ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]; then
  echo "ANDROID_HOME/ANDROID_SDK_ROOT não configurado." >&2
  exit 1
fi

gradle :app:assembleDebug --stacktrace
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
