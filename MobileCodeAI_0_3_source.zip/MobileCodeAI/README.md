# MobileCode AI — Android MVP 0.3

IDE mobile Android que usa o Termux instalado no aparelho como runtime local.

## O que funciona no código desta versão

- Criar projetos em `~/mobilecode-projects`.
- Clonar um repositório Git para um novo projeto.
- Abrir projetos locais.
- Ler, criar, editar e salvar arquivos do workspace.
- Executar comandos no Termux pelo `RunCommandService`.
- Git: `init`, `status`, `diff`, `add`, `commit`, `pull`, `push`, branches.
- Iniciar/encerrar preview em `http://127.0.0.1:5173`.
  - projeto com `package.json`: tenta `npm run dev`.
  - projeto sem `package.json`: tenta `python -m http.server`.
- WebView de preview.
- Diagnóstico de Termux, Git, Node/npm e Python.
- Agente de código com endpoint configurável compatível com Chat Completions.
- Ferramentas do agente:
  - `list_files`
  - `read_file`
  - `write_file`
  - `run_command`
  - `git_diff`
- Política de segurança mais restrita para comandos gerados pela IA.
- A API key da IA fica somente na memória e não é persistida.

## Arquitetura

```text
MobileCode AI (Android / Compose)
        |
        +-- Projects
        +-- AI Agent ---------+
        +-- Code Editor       |
        +-- Preview           |
        +-- Terminal          |
        +-- Git               |
        +-- Setup             |
                              v
                   Termux RunCommandService
                              |
                    ~/mobilecode-projects
                              |
               Git / Node / npm / Python
```

O editor, Git e terminal operam sobre os mesmos arquivos porque os arquivos do
projeto ficam no sandbox do Termux e são lidos/escritos por comandos executados
pelo próprio Termux.

## Configuração necessária no telefone

1. Instale e abra o Termux.
2. No Termux, crie/edite `~/.termux/termux.properties` e adicione:

```text
allow-external-apps=true
```

3. Feche e abra novamente o Termux.
4. Instale as ferramentas desejadas no Termux. Para desenvolvimento web, normalmente:
   `git`, `nodejs` e/ou `python`.
5. Instale o APK do MobileCode AI.
6. Autorize `RUN_COMMAND` quando o Android solicitar.
7. Abra **Setup** no MobileCode AI e toque em **Testar integração**.

## Build pelo Android Studio

Requisitos recomendados para este projeto:

- JDK 17
- Android SDK 35
- Build Tools 35.0.0
- Gradle 8.9

Abra a pasta no Android Studio, sincronize o projeto e use:

`Build > Build APK(s)`

O APK debug ficará em:

`app/build/outputs/apk/debug/app-debug.apk`

## Build por linha de comando

```sh
./build-apk.sh
```

## Build automático no GitHub

Este projeto inclui:

`.github/workflows/build-debug-apk.yml`

Ao enviar o repositório para GitHub, execute a action **Build Android APK**.
O artifact gerado se chama `MobileCodeAI-debug`.

## Agente de IA

A tela AI pede:

- URL do endpoint
- nome do modelo
- API key

O endpoint precisa aceitar um corpo no formato de Chat Completions com `model`
e `messages` e responder com `choices[0].message.content`.

O agente conversa com o modelo por um protocolo JSON simples e usa ferramentas
locais para modificar o projeto. O shell automático é propositalmente limitado;
o terminal digitado pelo usuário não usa essa política.

## Limitações desta versão

- O terminal ainda é execução de comandos, não um PTY interativo.
- O editor é nativo simples; Monaco ainda não está embutido.
- Autenticação GitHub não está embutida: HTTPS/SSH usa a configuração do Git no Termux.
- O runtime é o app Termux instalado separadamente, não uma cópia incorporada.
- O preview assume porta 5173.
- Esta entrega não contém um APK já compilado porque o ambiente usado para gerar
  os arquivos não possui Android SDK/aapt2/apksigner. O workflow incluído gera o APK.

## APK de referência

A integração foi preparada para o APK do Termux fornecido como referência,
utilizando `com.termux.RUN_COMMAND`, `RunCommandService`, argumentos, workdir,
stdin e retorno por `PendingIntent`.
