package dev.mobilecodeai.ai

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

data class AiConfig(
    val endpoint: String,
    val model: String,
    val apiKey: String
)

data class AiMessage(
    val role: String,
    val content: String
)

class AiClient {
    private val main = Handler(Looper.getMainLooper())

    fun chat(
        config: AiConfig,
        messages: List<AiMessage>,
        callback: (Result<String>) -> Unit
    ) {
        thread(name = "mobilecode-ai", isDaemon = true) {
            val result = runCatching {
                require(config.endpoint.startsWith("http://") || config.endpoint.startsWith("https://")) {
                    "Endpoint inválido."
                }
                require(config.model.isNotBlank()) { "Informe o modelo." }

                val connection = (URL(config.endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 30_000
                    readTimeout = 90_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Accept", "application/json")
                    if (config.apiKey.isNotBlank()) {
                        setRequestProperty("Authorization", "Bearer ${config.apiKey}")
                    }
                }

                val jsonMessages = JSONArray()
                messages.forEach { message ->
                    jsonMessages.put(
                        JSONObject()
                            .put("role", message.role)
                            .put("content", message.content)
                    )
                }

                val body = JSONObject()
                    .put("model", config.model)
                    .put("messages", jsonMessages)
                    .put("temperature", 0.1)

                connection.outputStream.bufferedWriter(Charsets.UTF_8).use {
                    it.write(body.toString())
                }

                val status = connection.responseCode
                val stream = if (status in 200..299) {
                    connection.inputStream
                } else {
                    connection.errorStream ?: connection.inputStream
                }
                val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                connection.disconnect()

                if (status !in 200..299) {
                    error("HTTP $status: ${response.take(2000)}")
                }

                val root = JSONObject(response)
                val choices = root.optJSONArray("choices")
                    ?: error("Resposta sem 'choices'. Use um endpoint compatível com chat completions.")
                val first = choices.optJSONObject(0)
                    ?: error("Resposta sem primeira escolha.")
                val message = first.optJSONObject("message")
                    ?: error("Resposta sem 'message'.")
                val content = message.optString("content")
                if (content.isBlank()) error("A IA retornou conteúdo vazio.")
                content
            }

            main.post { callback(result) }
        }
    }
}
