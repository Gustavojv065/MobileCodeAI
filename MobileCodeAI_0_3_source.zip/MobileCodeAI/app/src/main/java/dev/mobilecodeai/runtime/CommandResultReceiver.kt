package dev.mobilecodeai.runtime

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class CommandResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val requestId = intent.getStringExtra(EXTRA_REQUEST_ID) ?: return
        val extras = intent.extras

        val raw = buildMap {
            extras?.keySet()?.forEach { key ->
                put(key, extras.get(key)?.toString().orEmpty())
            }
        }

        fun stringFrom(vararg keys: String): String {
            for (key in keys) {
                val value = extras?.get(key)
                if (value != null) return value.toString()
            }
            return ""
        }

        fun intFrom(vararg keys: String): Int? {
            for (key in keys) {
                val value = extras?.get(key)
                when (value) {
                    is Int -> return value
                    is Number -> return value.toInt()
                    is String -> value.toIntOrNull()?.let { return it }
                }
            }
            return null
        }

        val stdout = stringFrom(
            "stdout",
            "com.termux.RUN_COMMAND_RESULT_STDOUT"
        ).ifBlank {
            raw.entries.firstOrNull { it.key.contains("stdout", ignoreCase = true) }?.value.orEmpty()
        }

        val stderr = stringFrom(
            "stderr",
            "com.termux.RUN_COMMAND_RESULT_STDERR"
        ).ifBlank {
            raw.entries.firstOrNull { it.key.contains("stderr", ignoreCase = true) }?.value.orEmpty()
        }

        val exitCode = intFrom(
            "exitCode",
            "exit_code",
            "com.termux.RUN_COMMAND_RESULT_EXIT_CODE"
        )

        val errorCode = intFrom(
            "err",
            "errCode",
            "errorCode",
            "com.termux.RUN_COMMAND_RESULT_ERR_CODE"
        )

        val errorMessage = stringFrom(
            "errmsg",
            "errMsg",
            "errorMessage",
            "com.termux.RUN_COMMAND_RESULT_ERRMSG"
        )

        CommandResultRegistry.complete(
            requestId,
            CommandResult(
                stdout = stdout,
                stderr = stderr,
                exitCode = exitCode,
                errorCode = errorCode,
                errorMessage = errorMessage,
                rawExtras = raw
            )
        )
    }

    companion object {
        const val EXTRA_REQUEST_ID = "mobilecode.request_id"
    }
}
