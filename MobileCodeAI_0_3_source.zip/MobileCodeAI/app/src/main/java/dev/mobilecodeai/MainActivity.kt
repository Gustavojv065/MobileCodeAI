package dev.mobilecodeai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import dev.mobilecodeai.ui.MobileCodeApp

class MainActivity : ComponentActivity() {

    private val termuxPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // The UI re-checks permission when the activity resumes / user opens Setup.
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestTermuxPermissionIfNeeded()

        setContent {
            MobileCodeApp()
        }
    }

    private fun requestTermuxPermissionIfNeeded() {
        val permission = TERMUX_RUN_COMMAND_PERMISSION
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            runCatching {
                termuxPermissionLauncher.launch(permission)
            }
        }
    }

    companion object {
        const val TERMUX_RUN_COMMAND_PERMISSION = "com.termux.permission.RUN_COMMAND"
    }
}
