package dev.mobilecodeai.ai

import dev.mobilecodeai.git.GitService
import dev.mobilecodeai.runtime.CommandRequest
import dev.mobilecodeai.runtime.CommandRunner
import dev.mobilecodeai.workspace.TermuxWorkspace
import org.json.JSONObject

class CodingAgent(
    private val client: AiClient,
    private val runner: CommandRunner,
    private val workspace: TermuxWorkspace,
    private val git: GitService
) {
    data class Event(
        val kind: Kind,
        val text: String
    ) {
        enum class Kind {
            INFO,
            TOOL,
            ERROR,
            DONE
        }
    }

    private val systemPrompt = """
        Você é o agente de código dentro de um IDE mobile. Trabalhe somente no workspace atual.
        Você possui as ferramentas abaixo. Responda SEMPRE com um único objeto JSON, sem markdown.

        Ações:
        {"action":"list_files"}
        {"action":"read_file","path":"src/app.js"}
        {"action":"write_file","path":"src/app.js","content":"conteúdo completo do arquivo"}
        {"action":"run_command","command":"npm test"}
        {"action":"git_diff"}
        {"action":"done","message":"resumo curto do que foi feito"}

        Regras:
        - Leia os arquivos relevantes antes de editar.
        - write_file substitui o arquivo inteiro; preserve conteúdo necessário.
        - Não tente acessar arquivos fora do workspace.
        - Use run_command apenas para inspeção, instalação/build/teste necessários.
        - Prefira comandos não interativos.
        - Depois de editar, verifique erros quando houver um comando de build/teste disponível.
        - Termine com action=done.
    """.trimIndent()

    fun run(
        prompt: String,
        config: AiConfig,
        onEvent: (Event) -> Unit
    ) {
        if (prompt.isBlank()) {
            onEvent(Event(Event.Kind.ERROR, "Prompt vazio."))
            return
        }

        val messages = mutableListOf(
            AiMessage("system", systemPrompt),
            AiMessage(
                "user",
                "Workspace: ${workspace.root}\nSolicitação do usuário: $prompt"
            )
        )

        step(config, messages, 0, onEvent)
    }

    private fun step(
        config: AiConfig,
        messages: MutableList<AiMessage>,
        step: Int,
        onEvent: (Event) -> Unit
    ) {
        if (step >= MAX_STEPS) {
            onEvent(Event(Event.Kind.ERROR, "O agente atingiu o limite de $MAX_STEPS etapas."))
            return
        }

        onEvent(Event(Event.Kind.INFO, "IA: etapa ${step + 1}…"))

        client.chat(config, messages) { result ->
            result.onFailure { error ->
                onEvent(Event(Event.Kind.ERROR, error.message ?: error.toString()))
            }.onSuccess { raw ->
                messages += AiMessage("assistant", raw)

                val json = parseJson(raw)
                if (json == null) {
                    onEvent(
                        Event(
                            Event.Kind.ERROR,
                            "A resposta da IA não veio no formato JSON esperado.\n${raw.take(2000)}"
                        )
                    )
                    return@onSuccess
                }

                when (val action = json.optString("action")) {
                    "list_files" -> {
                        onEvent(Event(Event.Kind.TOOL, "list_files"))
                        workspace.listFiles { files, commandResult ->
                            val output = if (commandResult.stderr.isNotBlank()) {
                                "ERRO:\n${commandResult.stderr}"
                            } else {
                                files.joinToString("\n")
                            }
                            continueWithToolResult(
                                config, messages, step, "list_files", output, onEvent
                            )
                        }
                    }

                    "read_file" -> {
                        val path = json.optString("path")
                        onEvent(Event(Event.Kind.TOOL, "read_file $path"))
                        runCatching {
                            workspace.readFile(path) { content, commandResult ->
                                val output = content
                                    ?: "ERRO:\n${commandResult.stderr.ifBlank { "Não foi possível ler o arquivo." }}"
                                continueWithToolResult(
                                    config, messages, step, "read_file $path", output, onEvent
                                )
                            }
                        }.onFailure {
                            continueWithToolResult(
                                config, messages, step, "read_file $path",
                                "ERRO: ${it.message}", onEvent
                            )
                        }
                    }

                    "write_file" -> {
                        val path = json.optString("path")
                        val content = json.optString("content")
                        onEvent(Event(Event.Kind.TOOL, "write_file $path"))
                        runCatching {
                            workspace.writeFile(path, content) { commandResult ->
                                val output = if (commandResult.stderr.isBlank()) {
                                    "OK: arquivo gravado."
                                } else {
                                    "ERRO:\n${commandResult.stderr}"
                                }
                                continueWithToolResult(
                                    config, messages, step, "write_file $path", output, onEvent
                                )
                            }
                        }.onFailure {
                            continueWithToolResult(
                                config, messages, step, "write_file $path",
                                "ERRO: ${it.message}", onEvent
                            )
                        }
                    }

                    "run_command" -> {
                        val command = json.optString("command")
                        val blocked = SafeAgentCommandPolicy.validate(command)
                        if (blocked != null) {
                            onEvent(Event(Event.Kind.TOOL, "run_command bloqueado: $command"))
                            continueWithToolResult(
                                config, messages, step, "run_command",
                                "ERRO: $blocked", onEvent
                            )
                        } else {
                            onEvent(Event(Event.Kind.TOOL, "run_command $command"))
                            runner.execute(
                                CommandRequest(command, workspace.root)
                            ) { commandResult ->
                                val output = buildString {
                                    if (commandResult.stdout.isNotBlank()) {
                                        append(commandResult.stdout)
                                    }
                                    if (commandResult.stderr.isNotBlank()) {
                                        if (isNotEmpty()) append('\n')
                                        append("STDERR:\n").append(commandResult.stderr)
                                    }
                                    commandResult.exitCode?.let {
                                        append("\nEXIT_CODE=").append(it)
                                    }
                                    if (isEmpty()) append("OK")
                                }
                                continueWithToolResult(
                                    config, messages, step, "run_command $command", output, onEvent
                                )
                            }
                        }
                    }

                    "git_diff" -> {
                        onEvent(Event(Event.Kind.TOOL, "git_diff"))
                        git.diff(workspace.root) { commandResult ->
                            val output = buildString {
                                if (commandResult.stdout.isNotBlank()) append(commandResult.stdout)
                                if (commandResult.stderr.isNotBlank()) {
                                    if (isNotEmpty()) append('\n')
                                    append(commandResult.stderr)
                                }
                                if (isEmpty()) append("(sem alterações)")
                            }
                            continueWithToolResult(
                                config, messages, step, "git_diff", output, onEvent
                            )
                        }
                    }

                    "done" -> {
                        val message = json.optString("message").ifBlank { "Concluído." }
                        onEvent(Event(Event.Kind.DONE, message))
                    }

                    else -> {
                        onEvent(
                            Event(
                                Event.Kind.ERROR,
                                "Ação desconhecida: '${action.ifBlank { "(vazia)" }}'."
                            )
                        )
                    }
                }
            }
        }
    }

    private fun continueWithToolResult(
        config: AiConfig,
        messages: MutableList<AiMessage>,
        step: Int,
        tool: String,
        output: String,
        onEvent: (Event) -> Unit
    ) {
        val capped = if (output.length > MAX_TOOL_OUTPUT) {
            output.take(MAX_TOOL_OUTPUT) + "\n…[saída truncada]"
        } else {
            output
        }

        messages += AiMessage(
            "user",
            "TOOL_RESULT [$tool]\n$capped\nEscolha a próxima ação e responda apenas JSON."
        )
        step(config, messages, step + 1, onEvent)
    }

    private fun parseJson(raw: String): JSONObject? {
        val trimmed = raw.trim()
        return runCatching {
            JSONObject(trimmed)
        }.getOrElse {
            val start = trimmed.indexOf('{')
            val end = trimmed.lastIndexOf('}')
            if (start >= 0 && end > start) {
                runCatching { JSONObject(trimmed.substring(start, end + 1)) }.getOrNull()
            } else {
                null
            }
        }
    }

    companion object {
        private const val MAX_STEPS = 18
        private const val MAX_TOOL_OUTPUT = 24_000
    }
}
