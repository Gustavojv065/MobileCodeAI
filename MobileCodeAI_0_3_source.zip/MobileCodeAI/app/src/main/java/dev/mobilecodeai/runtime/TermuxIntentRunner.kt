package dev.mobilecodeai.runtime

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

class TermuxIntentRunner(
    private val context: Context
) : CommandRunner {

    override fun isAvailable(): Boolean {
        return runCatching {
            context.packageManager.getPackageInfo(TERMUX_PACKAGE, 0)
        }.isSuccess
    }

    override fun execute(request: CommandRequest, callback: CommandCallback) {
        if (!isAvailable()) {
            callback.onResult(
                CommandResult(
                    stderr = "Termux não encontrado. Instale/abra o Termux antes de usar o runtime."
                )
            )
            return
        }

        val requestId = CommandResultRegistry.register(callback)

        val resultIntent = Intent(context, CommandResultReceiver::class.java).apply {
            putExtra(CommandResultReceiver.EXTRA_REQUEST_ID, requestId)
        }

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_MUTABLE
            } else {
                0
            }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestId.hashCode(),
            resultIntent,
            flags
        )

        val runIntent = Intent().apply {
            setClassName(TERMUX_PACKAGE, TERMUX_RUN_COMMAND_SERVICE)
            action = ACTION_RUN_COMMAND
            putExtra(EXTRA_PATH, TERMUX_BASH)
            putExtra(EXTRA_ARGUMENTS, arrayOf("-lc", request.command))
            putExtra(EXTRA_WORKDIR, request.workingDirectory)
            putExtra(EXTRA_BACKGROUND, true)
            request.stdin?.let { putExtra(EXTRA_STDIN, it) }
            putExtra(EXTRA_PENDING_INTENT, pendingIntent)
        }

        runCatching {
            context.startService(runIntent)
        }.onFailure { error ->
            CommandResultRegistry.complete(
                requestId,
                CommandResult(
                    stderr = buildString {
                        append(error.message ?: error.toString())
                        append(
                            "\nVerifique a permissão RUN_COMMAND e, no Termux, " +
                                "allow-external-apps=true."
                        )
                    }
                )
            )
        }
    }

    companion object {
        const val TERMUX_PACKAGE = "com.termux"
        const val TERMUX_RUN_COMMAND_SERVICE = "com.termux.app.RunCommandService"
        const val TERMUX_BASH = "/data/data/com.termux/files/usr/bin/bash"

        const val ACTION_RUN_COMMAND = "com.termux.RUN_COMMAND"
        const val EXTRA_PATH = "com.termux.RUN_COMMAND_PATH"
        const val EXTRA_ARGUMENTS = "com.termux.RUN_COMMAND_ARGUMENTS"
        const val EXTRA_WORKDIR = "com.termux.RUN_COMMAND_WORKDIR"
        const val EXTRA_STDIN = "com.termux.RUN_COMMAND_STDIN"
        const val EXTRA_BACKGROUND = "com.termux.RUN_COMMAND_BACKGROUND"
        const val EXTRA_PENDING_INTENT = "com.termux.RUN_COMMAND_PENDING_INTENT"
    }
}
