package dev.mobilecodeai.ui

import android.content.pm.PackageManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import dev.mobilecodeai.MainActivity
import dev.mobilecodeai.ai.*
import dev.mobilecodeai.git.GitService
import dev.mobilecodeai.preview.PreviewService
import dev.mobilecodeai.runtime.CommandRequest
import dev.mobilecodeai.runtime.CommandResult
import dev.mobilecodeai.runtime.TermuxIntentRunner
import dev.mobilecodeai.settings.AppPreferences
import dev.mobilecodeai.workspace.ProjectService
import dev.mobilecodeai.workspace.TermuxWorkspace

private enum class StudioTab(val label: String) {
    PROJECTS("Projects"),
    AI("AI"),
    CODE("Code"),
    PREVIEW("Preview"),
    TERMINAL("Terminal"),
    GIT("Git"),
    SETUP("Setup")
}

@Composable
fun MobileCodeApp() {
    val context = LocalContext.current
    val runner = remember { TermuxIntentRunner(context.applicationContext) }
    val prefs = remember { AppPreferences(context.applicationContext) }
    val git = remember { GitService(runner) }
    val projectService = remember { ProjectService(runner) }

    var projectRoot by remember { mutableStateOf(prefs.workspaceRoot) }
    val workspace = remember(projectRoot) { TermuxWorkspace(runner, projectRoot) }
    val preview = remember { PreviewService(runner) }
    var tab by remember { mutableStateOf(StudioTab.PROJECTS) }
    var terminalLog by remember {
        mutableStateOf(
            if (runner.isAvailable()) "Termux detectado.\n"
            else "Termux não foi detectado.\n"
        )
    }

    fun selectWorkspace(path: String) {
        projectRoot = path
        prefs.workspaceRoot = path
        tab = StudioTab.CODE
    }

    LaunchedEffect(projectRoot) {
        if (runner.isAvailable() && projectRoot == TermuxWorkspace.DEFAULT_ROOT) {
            workspace.ensureDemo { result ->
                if (result.stderr.isNotBlank()) {
                    terminalLog = appendLimited(
                        terminalLog,
                        "[workspace] ${result.stderr}\n"
                    )
                }
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = {
                Surface(tonalElevation = 2.dp) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    "MobileCode AI",
                                    style = MaterialTheme.typography.titleLarge
                                )
                                Text(
                                    projectRoot.substringAfterLast('/'),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            Text(
                                if (runner.isAvailable()) "Termux ●" else "Termux ○",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }

                        ScrollableTabRow(selectedTabIndex = tab.ordinal) {
                            StudioTab.entries.forEach { item ->
                                Tab(
                                    selected = tab == item,
                                    onClick = { tab = item },
                                    text = { Text(item.label) }
                                )
                            }
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (tab) {
                    StudioTab.PROJECTS -> ProjectsPane(
                        projectService = projectService,
                        git = git,
                        currentRoot = projectRoot,
                        onOpenProject = ::selectWorkspace
                    )

                    StudioTab.AI -> AiPane(
                        runner = runner,
                        workspace = workspace,
                        git = git,
                        prefs = prefs
                    )

                    StudioTab.CODE -> CodePane(workspace)

                    StudioTab.PREVIEW -> PreviewPane(
                        workspace = workspace,
                        preview = preview
                    )

                    StudioTab.TERMINAL -> TerminalPane(
                        initialLog = terminalLog,
                        runner = runner,
                        workdir = projectRoot,
                        onLogChanged = { terminalLog = it }
                    )

                    StudioTab.GIT -> GitPane(
                        git = git,
                        workspace = workspace
                    )

                    StudioTab.SETUP -> SetupPane(runner)
                }
            }
        }
    }
}

@Composable
private fun ProjectsPane(
    projectService: ProjectService,
    git: GitService,
    currentRoot: String,
    onOpenProject: (String) -> Unit
) {
    var projects by remember { mutableStateOf<List<String>>(emptyList()) }
    var newProject by remember { mutableStateOf("") }
    var repoUrl by remember { mutableStateOf("") }
    var cloneName by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }

    fun refresh() {
        projectService.listProjects { list, result ->
            projects = list
            status = if (result.stderr.isBlank()) {
                "${list.size} projeto(s)"
            } else {
                formatCommandResult(result)
            }
        }
    }

    LaunchedEffect(Unit) { refresh() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Projetos", style = MaterialTheme.typography.headlineSmall)
        Text("Atual: $currentRoot", style = MaterialTheme.typography.bodySmall)

        HorizontalDivider()

        Text("Criar projeto", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            value = newProject,
            onValueChange = { newProject = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Nome") },
            placeholder = { Text("meu-app") }
        )
        Button(
            enabled = newProject.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                status = "Criando projeto…"
                projectService.createProject(newProject) { path, result ->
                    status = formatCommandResult(result)
                    if (path != null) {
                        refresh()
                        onOpenProject(path)
                    }
                }
            }
        ) {
            Text("Criar e abrir")
        }

        HorizontalDivider()

        Text("Clonar Git", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            value = repoUrl,
            onValueChange = { repoUrl = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("URL do repositório") },
            placeholder = { Text("https://host/usuario/projeto.git") }
        )
        OutlinedTextField(
            value = cloneName,
            onValueChange = { cloneName = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Nome local (opcional)") }
        )
        Button(
            enabled = repoUrl.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                status = "Clonando…"
                projectService.cloneProject(
                    repoUrl = repoUrl,
                    name = cloneName.takeIf { it.isNotBlank() },
                    git = git
                ) { path, result ->
                    status = formatCommandResult(result)
                    if (path != null) {
                        refresh()
                        onOpenProject(path)
                    }
                }
            }
        ) {
            Text("Clonar e abrir")
        }

        HorizontalDivider()

        Text("Projetos locais", style = MaterialTheme.typography.titleMedium)
        if (projects.isEmpty()) {
            Text("Nenhum projeto listado.")
        } else {
            projects.forEach { name ->
                OutlinedButton(
                    onClick = {
                        projectService.pathFor(name)?.let(onOpenProject)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(name)
                }
            }
        }

        if (status.isNotBlank()) {
            Text(
                status,
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun AiPane(
    runner: TermuxIntentRunner,
    workspace: TermuxWorkspace,
    git: GitService,
    prefs: AppPreferences
) {
    var endpoint by remember { mutableStateOf(prefs.aiEndpoint) }
    var model by remember { mutableStateOf(prefs.aiModel) }
    var apiKey by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var log by remember { mutableStateOf("Pronto para editar o projeto com IA.\n") }
    var running by remember { mutableStateOf(false) }

    val agent = remember(workspace.root) {
        CodingAgent(
            client = AiClient(),
            runner = runner,
            workspace = workspace,
            git = git
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Agente de código", style = MaterialTheme.typography.headlineSmall)

        OutlinedTextField(
            value = endpoint,
            onValueChange = {
                endpoint = it
                prefs.aiEndpoint = it
            },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Endpoint compatível com Chat Completions") },
            placeholder = { Text("https://seu-provedor/.../chat/completions") }
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = model,
                onValueChange = {
                    model = it
                    prefs.aiModel = it
                },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Modelo") }
            )
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                label = { Text("API key") }
            )
        }

        Surface(
            modifier = Modifier.fillMaxWidth().weight(1f),
            tonalElevation = 1.dp
        ) {
            Text(
                text = log,
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.bodySmall
            )
        }

        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2,
            maxLines = 5,
            label = { Text("O que você quer alterar?") },
            placeholder = {
                Text("Ex.: crie uma landing page responsiva e rode o build")
            }
        )

        Button(
            enabled = !running &&
                prompt.isNotBlank() &&
                endpoint.isNotBlank() &&
                model.isNotBlank(),
            onClick = {
                running = true
                log = appendLimited(log, "\n> $prompt\n")
                val currentPrompt = prompt
                prompt = ""

                agent.run(
                    prompt = currentPrompt,
                    config = AiConfig(endpoint, model, apiKey)
                ) { event ->
                    log = appendLimited(log, "[${event.kind}] ${event.text}\n")
                    if (
                        event.kind == CodingAgent.Event.Kind.DONE ||
                        event.kind == CodingAgent.Event.Kind.ERROR
                    ) {
                        running = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (running) "Agente trabalhando…" else "Executar agente")
        }

        Text(
            "A chave fica apenas na memória desta sessão e não é salva pelo app.",
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
private fun CodePane(workspace: TermuxWorkspace) {
    var files by remember(workspace.root) { mutableStateOf<List<String>>(emptyList()) }
    var selected by remember(workspace.root) { mutableStateOf<String?>(null) }
    var text by remember(workspace.root) { mutableStateOf("") }
    var status by remember(workspace.root) { mutableStateOf("Carregando workspace…") }
    var menuOpen by remember { mutableStateOf(false) }
    var newFile by remember { mutableStateOf("") }

    fun openFile(path: String) {
        selected = path
        status = "Abrindo $path…"
        workspace.readFile(path) { content, result ->
            text = content.orEmpty()
            status = if (result.stderr.isBlank()) path else formatCommandResult(result)
        }
    }

    fun refresh() {
        workspace.listFiles { list, result ->
            files = list
            status = if (result.stderr.isBlank()) "${list.size} arquivo(s)" else formatCommandResult(result)
            if (selected == null && list.isNotEmpty()) {
                openFile(list.first())
            } else if (selected != null && selected !in list) {
                selected = null
                text = ""
            }
        }
    }

    LaunchedEffect(workspace.root) { refresh() }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(modifier = Modifier.weight(1f)) {
                OutlinedButton(
                    onClick = { menuOpen = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        selected ?: "Selecionar arquivo",
                        maxLines = 1
                    )
                }
                DropdownMenu(
                    expanded = menuOpen,
                    onDismissRequest = { menuOpen = false }
                ) {
                    files.take(150).forEach { file ->
                        DropdownMenuItem(
                            text = { Text(file) },
                            onClick = {
                                menuOpen = false
                                openFile(file)
                            }
                        )
                    }
                }
            }

            Button(onClick = { refresh() }) {
                Text("↻")
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = newFile,
                onValueChange = { newFile = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Novo arquivo") },
                placeholder = { Text("src/App.kt") }
            )
            Button(
                enabled = newFile.isNotBlank(),
                onClick = {
                    val path = newFile.trim()
                    workspace.createFile(path) { result ->
                        status = formatCommandResult(result)
                        if (result.succeeded) {
                            newFile = ""
                            refresh()
                            openFile(path)
                        }
                    }
                },
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Text("+")
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                status,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.weight(1f)
            )
            Button(
                enabled = selected != null,
                onClick = {
                    selected?.let { path ->
                        status = "Salvando $path…"
                        workspace.writeFile(path, text) { result ->
                            status = if (result.succeeded) {
                                "Salvo: $path"
                            } else {
                                formatCommandResult(result)
                            }
                        }
                    }
                }
            ) {
                Text("Salvar")
            }
        }

        BasicTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0E1014))
                .padding(14.dp),
            textStyle = TextStyle(
                color = Color(0xFFF2F4F8),
                fontFamily = FontFamily.Monospace
            )
        )
    }
}

@Composable
private fun PreviewPane(
    workspace: TermuxWorkspace,
    preview: PreviewService
) {
    var typedUrl by remember { mutableStateOf("http://127.0.0.1:5173") }
    var loadedUrl by remember { mutableStateOf(typedUrl) }
    var refreshToken by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = typedUrl,
                onValueChange = { typedUrl = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Preview URL") }
            )
            Button(
                onClick = {
                    loadedUrl = typedUrl
                    refreshToken++
                },
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Text("Abrir")
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                modifier = Modifier.weight(1f),
                onClick = {
                    status = "Iniciando preview…"
                    preview.start(workspace.root) { result ->
                        status = formatCommandResult(result)
                        loadedUrl = "http://127.0.0.1:5173"
                        typedUrl = loadedUrl
                        refreshToken++
                    }
                }
            ) {
                Text("Start")
            }
            OutlinedButton(
                modifier = Modifier.weight(1f),
                onClick = {
                    preview.stop(workspace.root) { result ->
                        status = formatCommandResult(result)
                    }
                }
            ) {
                Text("Stop")
            }
            OutlinedButton(
                modifier = Modifier.weight(1f),
                onClick = {
                    preview.log(workspace.root) { result ->
                        status = formatCommandResult(result)
                    }
                }
            ) {
                Text("Log")
            }
        }

        if (status.isNotBlank()) {
            Text(
                status,
                modifier = Modifier.padding(8.dp),
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.labelSmall
            )
        }

        key(refreshToken, loadedUrl) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    WebView(context).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = false
                        webViewClient = WebViewClient()
                        loadUrl(loadedUrl)
                    }
                }
            )
        }
    }
}

@Composable
private fun TerminalPane(
    initialLog: String,
    runner: TermuxIntentRunner,
    workdir: String,
    onLogChanged: (String) -> Unit
) {
    var command by remember(workdir) { mutableStateOf("") }
    var log by remember(workdir) { mutableStateOf(initialLog) }

    fun append(value: String) {
        log = appendLimited(log, value)
        onLogChanged(log)
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth().weight(1f),
            tonalElevation = 1.dp
        ) {
            Text(
                text = log.ifBlank { "Terminal pronto.\n" },
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                fontFamily = FontFamily.Monospace
            )
        }

        OutlinedTextField(
            value = command,
            onValueChange = { command = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Comando") },
            placeholder = { Text("git status") }
        )

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val current = command.trim()
                if (current.isNotEmpty()) {
                    append("\n$ $current\n")
                    command = ""
                    runner.execute(
                        CommandRequest(
                            command = current,
                            workingDirectory = workdir
                        )
                    ) { result ->
                        append(formatCommandResult(result))
                    }
                }
            }
        ) {
            Text("Executar no Termux")
        }
    }
}

@Composable
private fun GitPane(
    git: GitService,
    workspace: TermuxWorkspace
) {
    var commitMessage by remember { mutableStateOf("Atualização pelo MobileCode AI") }
    var log by remember { mutableStateOf("") }

    fun consume(prefix: String): (CommandResult) -> Unit = { result ->
        log = appendLimited(log, "\n[$prefix]\n${formatCommandResult(result)}")
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Git", style = MaterialTheme.typography.headlineSmall)
        Text(
            workspace.root,
            style = MaterialTheme.typography.labelSmall
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                modifier = Modifier.weight(1f),
                onClick = { git.status(workspace.root, consume("status")) }
            ) {
                Text("Status")
            }
            Button(
                modifier = Modifier.weight(1f),
                onClick = { git.diff(workspace.root, consume("diff")) }
            ) {
                Text("Diff")
            }
            OutlinedButton(
                modifier = Modifier.weight(1f),
                onClick = { git.init(workspace.root, consume("init")) }
            ) {
                Text("Init")
            }
        }

        OutlinedTextField(
            value = commitMessage,
            onValueChange = { commitMessage = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Mensagem do commit") }
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                modifier = Modifier.weight(1f),
                onClick = { git.addAll(workspace.root, consume("add")) }
            ) {
                Text("Add all")
            }
            Button(
                modifier = Modifier.weight(1f),
                enabled = commitMessage.isNotBlank(),
                onClick = {
                    git.commit(workspace.root, commitMessage, consume("commit"))
                }
            ) {
                Text("Commit")
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                modifier = Modifier.weight(1f),
                onClick = { git.pull(workspace.root, consume("pull")) }
            ) {
                Text("Pull")
            }
            OutlinedButton(
                modifier = Modifier.weight(1f),
                onClick = { git.push(workspace.root, consume("push")) }
            ) {
                Text("Push")
            }
            OutlinedButton(
                modifier = Modifier.weight(1f),
                onClick = { git.branches(workspace.root, consume("branches")) }
            ) {
                Text("Branches")
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth().weight(1f),
            tonalElevation = 1.dp
        ) {
            Text(
                text = log.ifBlank { "Saída Git aparecerá aqui." },
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun SetupPane(
    runner: TermuxIntentRunner
) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    var diagnostics by remember { mutableStateOf("") }

    val termuxInstalled = remember(refresh) { runner.isAvailable() }
    val permissionGranted = remember(refresh) {
        ContextCompat.checkSelfPermission(
            context,
            MainActivity.TERMUX_RUN_COMMAND_PERMISSION
        ) == PackageManager.PERMISSION_GRANTED
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Setup / Diagnóstico", style = MaterialTheme.typography.headlineSmall)
        Text("Termux instalado: ${if (termuxInstalled) "SIM" else "NÃO"}")
        Text("Permissão RUN_COMMAND: ${if (permissionGranted) "SIM" else "NÃO"}")

        Text(
            "No Termux, habilite comandos externos adicionando esta linha em " +
                "~/.termux/termux.properties:",
            style = MaterialTheme.typography.bodyMedium
        )
        Surface(tonalElevation = 1.dp) {
            Text(
                "allow-external-apps=true",
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                fontFamily = FontFamily.Monospace
            )
        }

        Text(
            "Para desenvolvimento web, tenha Git e pelo menos Node.js/npm ou Python instalados no Termux.",
            style = MaterialTheme.typography.bodyMedium
        )

        Button(
            modifier = Modifier.fillMaxWidth(),
            enabled = termuxInstalled,
            onClick = {
                diagnostics = "Testando…"
                runner.execute(
                    CommandRequest(
                        command = """
                            echo "runtime=ok"
                            printf "shell="; command -v bash || true
                            printf "git="; command -v git || true
                            printf "node="; command -v node || true
                            printf "npm="; command -v npm || true
                            printf "python="; command -v python || command -v python3 || true
                        """.trimIndent()
                    )
                ) { result ->
                    diagnostics = formatCommandResult(result)
                    refresh++
                }
            }
        ) {
            Text("Testar integração")
        }

        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = { refresh++ }
        ) {
            Text("Atualizar status")
        }

        if (diagnostics.isNotBlank()) {
            Surface(tonalElevation = 1.dp) {
                Text(
                    diagnostics,
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

private fun formatCommandResult(result: CommandResult): String =
    buildString {
        if (result.stdout.isNotBlank()) append(result.stdout).append('\n')
        if (result.stderr.isNotBlank()) append(result.stderr).append('\n')
        if (result.errorMessage.isNotBlank()) {
            append("ERRO: ").append(result.errorMessage).append('\n')
        }
        result.errorCode?.let { append("[error ").append(it).append("]\n") }
        result.exitCode?.let { append("[exit ").append(it).append("]\n") }

        if (
            result.stdout.isBlank() &&
            result.stderr.isBlank() &&
            result.errorMessage.isBlank() &&
            result.exitCode == null &&
            result.errorCode == null &&
            result.rawExtras.isNotEmpty()
        ) {
            append(result.rawExtras.toString()).append('\n')
        }

        if (isEmpty()) append("OK\n")
    }

private fun appendLimited(current: String, addition: String): String {
    val combined = current + addition
    return if (combined.length > 80_000) {
        "…[log truncado]\n" + combined.takeLast(75_000)
    } else {
        combined
    }
}
