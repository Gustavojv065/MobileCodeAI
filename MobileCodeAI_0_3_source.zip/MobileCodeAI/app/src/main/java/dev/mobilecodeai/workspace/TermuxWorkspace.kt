package dev.mobilecodeai.workspace

import dev.mobilecodeai.runtime.CommandRequest
import dev.mobilecodeai.runtime.CommandResult
import dev.mobilecodeai.runtime.CommandRunner

class TermuxWorkspace(
    private val runner: CommandRunner,
    val root: String
) {
    fun ensureDemo(callback: (CommandResult) -> Unit = {}) {
        val html = """
            <!doctype html>
            <html lang="pt-BR">
            <head>
              <meta charset="utf-8" />
              <meta name="viewport" content="width=device-width,initial-scale=1" />
              <title>MobileCode AI</title>
              <style>
                :root { color-scheme: dark; }
                body { font-family: system-ui; background:#0f1115; color:#f2f4f8; padding:24px; }
                .card { max-width:720px; margin:40px auto; padding:28px; border:1px solid #30343b;
                        border-radius:20px; background:#171a20; }
                code { color:#9fc2ff; }
                button { padding:12px 16px; border-radius:12px; border:0; cursor:pointer; }
              </style>
            </head>
            <body>
              <div class="card">
                <h1>MobileCode AI</h1>
                <p>Projeto criado no workspace do Termux.</p>
                <p>Edite <code>index.html</code> na aba Code e visualize no Preview.</p>
                <button onclick="document.querySelector('p').textContent='JavaScript funcionando ✓'">
                  Testar
                </button>
              </div>
            </body>
            </html>
        """.trimIndent()

        val command = """
            mkdir -p ${shellQuote(root)}
            cd ${shellQuote(root)}
            if [ ! -f index.html ]; then
              cat > index.html
            fi
        """.trimIndent()

        runner.execute(
            CommandRequest(
                command = command,
                stdin = html
            )
        ) { callback(it) }
    }

    fun listFiles(callback: (List<String>, CommandResult) -> Unit) {
        runner.execute(
            CommandRequest(
                command = "find . -maxdepth 8 -type f " +
                    "! -path './.git/*' ! -path './node_modules/*' -print | " +
                    "sed 's#^\\./##' | sort | head -500",
                workingDirectory = root
            )
        ) { result ->
            val files = result.stdout
                .lineSequence()
                .map { it.trim() }
                .filter { it.isNotEmpty() && isSafeRelativePath(it) }
                .toList()
            callback(files, result)
        }
    }

    fun readFile(relativePath: String, callback: (String?, CommandResult) -> Unit) {
        requireSafe(relativePath)
        runner.execute(
            CommandRequest(
                command = "cat -- ${shellQuote(relativePath)}",
                workingDirectory = root
            )
        ) { result ->
            val ok = result.exitCode == null || result.exitCode == 0
            callback(if (ok && result.errorCode == null) result.stdout else null, result)
        }
    }

    fun writeFile(
        relativePath: String,
        content: String,
        callback: (CommandResult) -> Unit
    ) {
        requireSafe(relativePath)
        val quoted = shellQuote(relativePath)
        val command = """
            mkdir -p -- "$(dirname -- $quoted)"
            cat > $quoted
        """.trimIndent()

        runner.execute(
            CommandRequest(
                command = command,
                workingDirectory = root,
                stdin = content
            )
        ) { callback(it) }
    }

    fun createFile(relativePath: String, callback: (CommandResult) -> Unit) {
        requireSafe(relativePath)
        runner.execute(
            CommandRequest(
                command = "mkdir -p -- \"$(dirname -- ${shellQuote(relativePath)})\" && " +
                    "touch -- ${shellQuote(relativePath)}",
                workingDirectory = root
            )
        ) { callback(it) }
    }

    fun deleteFile(relativePath: String, callback: (CommandResult) -> Unit) {
        requireSafe(relativePath)
        runner.execute(
            CommandRequest(
                command = "rm -f -- ${shellQuote(relativePath)}",
                workingDirectory = root
            )
        ) { callback(it) }
    }

    private fun requireSafe(path: String) {
        require(isSafeRelativePath(path)) { "Caminho inválido: $path" }
    }

    private fun isSafeRelativePath(path: String): Boolean {
        if (
            path.isBlank() ||
            path.startsWith("/") ||
            path.contains('\u0000') ||
            path.contains('\n') ||
            path.contains('\r')
        ) {
            return false
        }
        return path.split('/').none { it == ".." }
    }

    private fun shellQuote(value: String): String =
        "'" + value.replace("'", "'\"'\"'") + "'"

    companion object {
        const val PROJECTS_ROOT = "/data/data/com.termux/files/home/mobilecode-projects"
        const val DEFAULT_ROOT = "$PROJECTS_ROOT/welcome"
    }
}
