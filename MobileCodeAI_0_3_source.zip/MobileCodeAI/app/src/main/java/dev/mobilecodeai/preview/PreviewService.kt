package dev.mobilecodeai.preview

import dev.mobilecodeai.runtime.CommandRequest
import dev.mobilecodeai.runtime.CommandResult
import dev.mobilecodeai.runtime.CommandRunner

class PreviewService(
    private val runner: CommandRunner
) {
    fun start(workdir: String, callback: (CommandResult) -> Unit) {
        val command = """
            if [ -f .mobilecode-preview.pid ]; then
              kill "$(cat .mobilecode-preview.pid)" >/dev/null 2>&1 || true
              rm -f .mobilecode-preview.pid
            fi

            if [ -f package.json ] && command -v npm >/dev/null 2>&1; then
              nohup npm run dev -- --host 127.0.0.1 --port 5173 > .mobilecode-preview.log 2>&1 &
              echo ${'$'}! > .mobilecode-preview.pid
              echo "Preview iniciado via npm em http://127.0.0.1:5173"
            elif command -v python >/dev/null 2>&1; then
              nohup python -m http.server 5173 --bind 127.0.0.1 > .mobilecode-preview.log 2>&1 &
              echo ${'$'}! > .mobilecode-preview.pid
              echo "Preview iniciado via Python em http://127.0.0.1:5173"
            elif command -v python3 >/dev/null 2>&1; then
              nohup python3 -m http.server 5173 --bind 127.0.0.1 > .mobilecode-preview.log 2>&1 &
              echo ${'$'}! > .mobilecode-preview.pid
              echo "Preview iniciado via Python em http://127.0.0.1:5173"
            else
              echo "Instale Node.js/npm ou Python no Termux para iniciar o preview." >&2
              exit 127
            fi
        """.trimIndent()

        runner.execute(
            CommandRequest(command = command, workingDirectory = workdir)
        ) { callback(it) }
    }

    fun stop(workdir: String, callback: (CommandResult) -> Unit) {
        val command = """
            if [ -f .mobilecode-preview.pid ]; then
              kill "$(cat .mobilecode-preview.pid)" >/dev/null 2>&1 || true
              rm -f .mobilecode-preview.pid
              echo "Preview encerrado."
            else
              echo "Nenhum preview iniciado pelo MobileCode AI."
            fi
        """.trimIndent()
        runner.execute(CommandRequest(command, workdir)) { callback(it) }
    }

    fun log(workdir: String, callback: (CommandResult) -> Unit) {
        runner.execute(
            CommandRequest(
                "test -f .mobilecode-preview.log && tail -80 .mobilecode-preview.log || true",
                workdir
            )
        ) { callback(it) }
    }
}
