package dev.mobilecodeai.settings

import android.content.Context
import dev.mobilecodeai.workspace.TermuxWorkspace

class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("mobilecode.preferences", Context.MODE_PRIVATE)

    var workspaceRoot: String
        get() = prefs.getString(KEY_WORKSPACE, TermuxWorkspace.DEFAULT_ROOT)
            ?: TermuxWorkspace.DEFAULT_ROOT
        set(value) {
            prefs.edit().putString(KEY_WORKSPACE, value).apply()
        }

    var aiEndpoint: String
        get() = prefs.getString(KEY_AI_ENDPOINT, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_AI_ENDPOINT, value).apply()
        }

    var aiModel: String
        get() = prefs.getString(KEY_AI_MODEL, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_AI_MODEL, value).apply()
        }

    companion object {
        private const val KEY_WORKSPACE = "workspaceRoot"
        private const val KEY_AI_ENDPOINT = "aiEndpoint"
        private const val KEY_AI_MODEL = "aiModel"
    }
}
