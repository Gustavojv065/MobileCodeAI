package dev.mobilecodeai.runtime

import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

object CommandResultRegistry {
    private val callbacks = ConcurrentHashMap<String, CommandCallback>()

    fun register(callback: CommandCallback): String {
        val id = UUID.randomUUID().toString()
        callbacks[id] = callback
        return id
    }

    fun complete(id: String, result: CommandResult) {
        callbacks.remove(id)?.onResult(result)
    }

    fun cancel(id: String) {
        callbacks.remove(id)
    }
}
