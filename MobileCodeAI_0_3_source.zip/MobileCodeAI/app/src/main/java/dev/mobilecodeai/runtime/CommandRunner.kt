package dev.mobilecodeai.runtime

data class CommandRequest(
    val command: String,
    val workingDirectory: String = "/data/data/com.termux/files/home",
    val stdin: String? = null
)

data class CommandResult(
    val stdout: String = "",
    val stderr: String = "",
    val exitCode: Int? = null,
    val errorCode: Int? = null,
    val errorMessage: String = "",
    val rawExtras: Map<String, String> = emptyMap()
) {
    val succeeded: Boolean
        get() = (exitCode == null || exitCode == 0) &&
            errorCode == null &&
            errorMessage.isBlank()
}

fun interface CommandCallback {
    fun onResult(result: CommandResult)
}

interface CommandRunner {
    fun isAvailable(): Boolean
    fun execute(request: CommandRequest, callback: CommandCallback)
}
