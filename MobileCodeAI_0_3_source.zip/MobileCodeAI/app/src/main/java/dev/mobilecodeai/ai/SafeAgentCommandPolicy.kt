package dev.mobilecodeai.ai

object SafeAgentCommandPolicy {
    private val allowedExecutables = setOf(
        "git",
        "npm",
        "npx",
        "node",
        "pnpm",
        "yarn",
        "python",
        "python3",
        "ls",
        "pwd",
        "find",
        "grep",
        "head",
        "tail",
        "cat"
    )

    fun validate(command: String): String? {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return "Comando vazio."
        if (trimmed.contains('\n') || trimmed.contains('\r')) {
            return "O agente só pode executar um comando por vez."
        }

        val lower = trimmed.lowercase()
        val blockedFragments = listOf(
            "rm ",
            "rm\t",
            "sudo",
            " su ",
            "dd ",
            "mkfs",
            "reboot",
            "shutdown",
            "pkg uninstall",
            "apt remove",
            "termux-reset",
            "../",
            "/data/data/",
            "/sdcard",
            "/storage/",
            "> /",
            "| sh",
            "| bash",
            "chmod 777"
        )
        if (blockedFragments.any { lower.contains(it) }) {
            return "Comando bloqueado pela política de segurança do agente."
        }

        val first = trimmed
            .substringBefore(' ')
            .substringBefore('\t')
            .removePrefix("./")

        if (first !in allowedExecutables) {
            return "Executável '$first' não permitido para execução automática."
        }

        return null
    }
}
