package dev.mobilecodeai.workspace

import dev.mobilecodeai.git.GitService
import dev.mobilecodeai.runtime.CommandRequest
import dev.mobilecodeai.runtime.CommandResult
import dev.mobilecodeai.runtime.CommandRunner

class ProjectService(
    private val runner: CommandRunner
) {
    fun listProjects(callback: (List<String>, CommandResult) -> Unit) {
        runner.execute(
            CommandRequest(
                command = "mkdir -p ${shellQuote(TermuxWorkspace.PROJECTS_ROOT)}; " +
                    "find ${shellQuote(TermuxWorkspace.PROJECTS_ROOT)} -mindepth 1 -maxdepth 1 " +
                    "-type d -printf '%f\\n' | sort"
            )
        ) { result ->
            callback(
                result.stdout.lineSequence()
                    .map { it.trim() }
                    .filter { it.matches(Regex("[A-Za-z0-9._-]+")) }
                    .toList(),
                result
            )
        }
    }

    fun createProject(name: String, callback: (String?, CommandResult) -> Unit) {
        val safeName = normalizeProjectName(name)
        if (safeName == null) {
            callback(
                null,
                CommandResult(stderr = "Use apenas letras, números, ponto, hífen ou sublinhado.")
            )
            return
        }

        val root = "${TermuxWorkspace.PROJECTS_ROOT}/$safeName"
        TermuxWorkspace(runner, root).ensureDemo { result ->
            callback(if (result.succeeded) root else null, result)
        }
    }

    fun cloneProject(
        repoUrl: String,
        name: String?,
        git: GitService,
        callback: (String?, CommandResult) -> Unit
    ) {
        val derived = name?.takeIf { it.isNotBlank() }
            ?: repoUrl.substringAfterLast('/').removeSuffix(".git")
        val safeName = normalizeProjectName(derived)
        if (safeName == null) {
            callback(null, CommandResult(stderr = "Nome de projeto inválido."))
            return
        }

        val destination = "${TermuxWorkspace.PROJECTS_ROOT}/$safeName"
        runner.execute(
            CommandRequest("mkdir -p ${shellQuote(TermuxWorkspace.PROJECTS_ROOT)}")
        ) { prep ->
            if (!prep.succeeded) {
                callback(null, prep)
                return@execute
            }
            git.clone(repoUrl, destination) { result ->
                callback(if (result.succeeded) destination else null, result)
            }
        }
    }

    fun pathFor(projectName: String): String? =
        normalizeProjectName(projectName)?.let { "${TermuxWorkspace.PROJECTS_ROOT}/$it" }

    private fun normalizeProjectName(value: String): String? {
        val trimmed = value.trim()
        return trimmed.takeIf {
            it.isNotEmpty() &&
                it.length <= 80 &&
                it != "." &&
                it != ".." &&
                it.matches(Regex("[A-Za-z0-9._-]+"))
        }
    }

    private fun shellQuote(value: String): String =
        "'" + value.replace("'", "'\"'\"'") + "'"
}
