package dev.mobilecodeai.git

import dev.mobilecodeai.runtime.CommandCallback
import dev.mobilecodeai.runtime.CommandRequest
import dev.mobilecodeai.runtime.CommandRunner

class GitService(
    private val runner: CommandRunner
) {
    fun status(workdir: String, callback: CommandCallback) =
        runner.execute(CommandRequest("git status --short --branch", workdir), callback)

    fun diff(workdir: String, callback: CommandCallback) =
        runner.execute(CommandRequest("git diff -- .", workdir), callback)

    fun init(workdir: String, callback: CommandCallback) =
        runner.execute(CommandRequest("git init", workdir), callback)

    fun clone(repoUrl: String, destination: String, callback: CommandCallback) {
        val parent = destination.substringBeforeLast('/', missingDelimiterValue = destination)
        val folder = destination.substringAfterLast('/')
        runner.execute(
            CommandRequest(
                command = "git clone -- ${shellQuote(repoUrl)} ${shellQuote(folder)}",
                workingDirectory = parent
            ),
            callback
        )
    }

    fun addAll(workdir: String, callback: CommandCallback) =
        runner.execute(CommandRequest("git add -A", workdir), callback)

    fun commit(workdir: String, message: String, callback: CommandCallback) =
        runner.execute(
            CommandRequest("git commit -m ${shellQuote(message)}", workdir),
            callback
        )

    fun pull(workdir: String, callback: CommandCallback) =
        runner.execute(CommandRequest("git pull --ff-only", workdir), callback)

    fun push(workdir: String, callback: CommandCallback) =
        runner.execute(CommandRequest("git push", workdir), callback)

    fun branches(workdir: String, callback: CommandCallback) =
        runner.execute(
            CommandRequest("git branch --format='%(refname:short)'", workdir),
            callback
        )

    private fun shellQuote(value: String): String =
        "'" + value.replace("'", "'\"'\"'") + "'"
}
